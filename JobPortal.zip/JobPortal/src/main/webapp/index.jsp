<% response.sendRedirect("/LoginReg/welcome");%>
